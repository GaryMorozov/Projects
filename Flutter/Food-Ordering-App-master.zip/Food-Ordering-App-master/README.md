# Food Ordering App - Flutter UI

## [Watch it on YouTube](https://youtu.be/F0ujC60wHwc)

**Packages we are using:**

- flutter_svg: [link](https://pub.dev/packages/flutter_svg)
- smooth_star_rating: [link](https://pub.dev/packages/smooth_star_rating)

We design two pages one is the home page and another one is details page that will help you to design clear interfaces for food delivery app faster and easier.

### Food App Final UI

![App UI](/ui.png)
