class AppUser {
  final String email;
  final String password;
  final String token;

  AppUser({required this.email, required this.password, required this.token});
}
