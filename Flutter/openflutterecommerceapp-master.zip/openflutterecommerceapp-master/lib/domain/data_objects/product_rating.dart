class ProductRating {
  final double rating;
  final int quantity;

  ProductRating({
    required this.rating,
    required this.quantity,
  });
}
