
class CategoriesByFilterParams {
  final int categoryId;

  CategoriesByFilterParams({
    required this.categoryId
  });
}