class AppSettings {
  static bool cacheIsEnabled = true;
  static bool profileEnabled = true;
}
