import 'model/filter_rules_test.dart' as filter_rules_test;

void main() {
  filter_rules_test.main();
}