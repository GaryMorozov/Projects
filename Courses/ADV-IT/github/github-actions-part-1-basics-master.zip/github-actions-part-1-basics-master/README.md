# GitHub Actions Part-1 Basics


Status of Last Deployment:<br>
<img src="https://github.com/adv4000/github-actions-part-1-basics/workflows/My-GitHubActions-Basics/badge.svg?branch=master"><br>


Copyleft by Denis Astahov ADV-IT 2019.
