#!/bin/bash
echo "---Start Script---"
echo "Hello From example.sh file!"
who
ls -la
pwd
echo "---End Script---"
